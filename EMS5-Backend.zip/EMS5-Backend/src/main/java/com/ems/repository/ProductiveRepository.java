package com.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.ems.entity.ProductiveEntity;

public interface ProductiveRepository extends JpaRepository<ProductiveEntity,Long>{

}
